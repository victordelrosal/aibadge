This is a practice folder for the AI Badge lesson "AI on the Terminal".
Driftwood Café is made up. Nothing here is real, so let your AI agent loose on it.
